const express = require('express')
const sls = require('serverless-http') 
const { InMemorySigner } = require('@taquito/signer');
const { TezBridgeSigner } = '@taquito/tezbridge-signer';
const {TezosToolkit, MichelCodecPacker } = require('@taquito/taquito');

const bodyParser = require('body-parser')
const app = express()
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

const acc = require('./ithacanet.json')

const request = require('request');
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');

app.set('views', __dirname);

const tezos = new TezosToolkit('https://ithacanet.smartpy.io');
const contractKey='KT1Kuwgi2PXuiSkHdNtmS8p1hAb21seijY5E';

const privateKey ="tz1M6x9Y4cAGWpmkJjrSopTLfTLAUVmCZoLv"
const https = require("https");
tezos.setPackerProvider(new MichelCodecPacker());
tezos.setSignerProvider(InMemorySigner.fromFundraiser(acc.email, acc.password, acc.mnemonic.join(' ')))




// Tezos.contract

  //*********************************Get Balance**************************************8 */

  app.get('/getBalance', (req,res) => {
    const address =req.body.address
    const balance =req.body.balance
    
    tezos.tz
    .getBalance(privateKey)
    .then((balance) => res.send(`Public key balance is: ${balance.toNumber() / 1000000} ꜩ`))
    .catch((error) => res.send(JSON.stringify(error)));

    
})



    //////////////////////////////////////////////////////////////////////////////////////////////////////
    ////                           ALL POST FUNCTIONS FOR THE SMART CONTRACT                          ////   
    //////////////////////////////////////////////////////////////////////////////////////////////////////




//*********************************Add Assurer***************************************/
app.post('/addAssurer', (req,res) => {
  tezos.contract
    .at(contractKey)
    .then((contract) => {
      const email =req.body.email

      console.log(`Adding a assurer email: ${email}...`);
      return contract.methods.addAssure(email).send();
    })
    .then((op) => {
      console.log(`Awaiting for ${op.hash} to be confirmed...`);
      return res.send(op.hash);
    })
  
.catch((error) => {
          // console.log(`Error: ${JSON.stringify(error, null, 2)}`))
          console.log(`Error: verify your infos`);
          return res.status(400);
          })      .finally(()=>{
      res.end();
    })
  
  })



  //*********************************Add Transactions to kovami wallet***************************************/
app.post('/addTransaction', (req,res) => {
  tezos.contract
    .at(contractKey)
    .then((contract) => {
      const senderAddress =req.body.senderAddress
      const opHash =req.body.opHash
      const reason =req.body.reason

      console.log(`Adding a transaction hash: ${opHash} to kovami wallet...`);
      return contract.methods.kovamiWallet(opHash, reason ,senderAddress).send();
    })
    .then((op) => {
      console.log(`Awaiting for ${op.hash} to be confirmed...`);
      return res.send(op.hash);
    })
  
.catch((error) => {
          // console.log(`Error: ${JSON.stringify(error, null, 2)}`))
          console.log(`Error: verify your infos`);
          return res.status(400);
          })      .finally(()=>{
      res.end();
    })
  
  })



    //*********************************Add Transactions to Conseiller wallet***************************************/
app.post('/addConseillerTransaction', (req,res) => {
  tezos.contract
    .at(contractKey)
    .then((contract) => {
      const senderAddress =req.body.senderAddress
      const opHash =req.body.opHash
      const reason =req.body.reason

      console.log(`Adding a transaction hash: ${opHash} to conseiller wallet...`);
      return contract.methods.conseillerWallet(opHash, reason ,senderAddress).send();
    })
    .then((op) => {
      console.log(`Awaiting for ${op.hash} to be confirmed...`);
      return res.send(op.hash);
    })
  
.catch((error) => {
          // console.log(`Error: ${JSON.stringify(error, null, 2)}`))
          console.log(`Error: verify your infos`);
          return res.status(400);
          })      .finally(()=>{
      res.end();
    })
  
  })


  
    //*********************************add subscription for an assurer**************************************8 */



app.post('/addSubscription', (req,res) => {
  tezos.contract
    .at(contractKey)
    .then((contract) => {
      const email = req.body.email
      const amount = req.body.amount
      const immatriculation = req.body.immatriculation
      const mode = req.body.mode
      const dateUpdate = req.body.dateUpdate
      const dateEmission = req.body.dateEmission
      const dateEcheance = req.body.dateEcheance
      const categorieDuvehicule = req.body.categorieDuvehicule
      const puissance = req.body.puissance
      const zone = req.body.zone
      const numeroAttestation = req.body.numeroAttestation
      const numeroCarteRose = req.body.numeroCarteRose
      const fc = req.body.fc
      const dta = req.body.dta
      const acc = req.body.acc
      const pna = req.body.pna
      const pttc = req.body.pttc
      const emailSouscripteur = req.body.emailSouscripteur
     
      console.log(email,amount, mode,dateUpdate, dateEmission.toString(), dateEcheance.toString(), categorieDuvehicule,puissance, zone,immatriculation,numeroAttestation,numeroCarteRose, fc, dta, acc,pna,pttc,emailSouscripteur.toString())
      console.log(`Adding an subscription with id ${email} for assurer ${emailSouscripteur}...`);
      // return contract.methods.addSouscription(email, amount, mode,dateUpdate,dateEmission, dateEcheance, categorieDuvehicule,puissance, zone, immatriculation, numeroAttestation,numeroCarteRose, fc, dta, acc, pna, pttc, emailSouscripteur).send();
      return contract.methods.addSouscription(acc,amount,categorieDuvehicule,dateEcheance,dateEmission, dateUpdate,dta, email.toString(), emailSouscripteur.toString(), fc,immatriculation, mode,numeroAttestation,numeroCarteRose, pna, pttc,  puissance, zone).send()

    })
      .then((op) => {
        console.log(`Awaiting for ${op.hash} to be confirmed...`)
        console.log(`Gas Used: `+ op.consumedGas);
        return res.send(op.hash);
      })
    
  .catch((error) => {
            console.log(`Error: ${JSON.stringify(error, null, 2)}`+error)
            // console.log(`Error: verify your infos`);
            return res.status(400);
            })      .finally(()=>{
        res.end();
      })
    
    })
  


   //end-point qui permet de transférer des tez au portefeuille des clients
app.post('/transfer', (req,res) => {
  const amount = req.body.amount;
  const address = req.body.address;
// const amount = 2;
// const address = 'tz1h3rQ8wBxFd8L9B3d7Jhaawu6Z568XU3xY';

console.log(`Transfering ${amount} ꜩ to ${address}...`);
tezos.contract
  .transfer({ to: address, amount: amount })
  .then((op) => {
    console.log(`Waiting for ${op.hash} to be confirmed...`);
    // return op.confirmation(1).then(() => op.hash);
    return res.send(op.hash);
  })
  .then((hash) => console.log(`Operation injected: https://ithaca.tzstats.com/${hash}`))
  .catch((error) => console.log(`Error: ${error} ${JSON.stringify(error, null, 2)}`));

}
)



    //////////////////////////////////////////////////////////////////////////////////////////////////////
    ////                           ALL GET FUNCTIONS FOR THE SMART CONTRACT                          ////   
    //////////////////////////////////////////////////////////////////////////////////////////////////////


    app.get("/storage", async (req, res) => {
      tezos.contract
      .at(contractKey)
      .then((contract) => {
        console.log('Fetching the storage of the contract...')
        contract.storage().then((r) =>{
         console.log("the big map: ", r.Assures)
         const valueMap = r.Assures.getMultipleValues(['jane@gmail.com']);
     
         valueMap.then((a)=> {
           a.forEach((i)=>{
             console.log("item: ", i)
           })
           console.log(`The value associated with the specified key of the map is `, a);
         }).catch((err)=> {
            console.log("error: ", err)
          })
            
       })
        return contract.storage()
      })
      .then((storage) => {
       console.log('Fetching the big map values...\n')
       // console.log("storage: ", storage.projects)
        return storage;
      })
     })
     
     

    /*******************************************Get contract******************************************** */
    app.get("/contract", async (req, res) => {
      const mapUsed='addAssure';
      https.get('https://api.ithacanet.tzkt.io/v1/contracts/KT1Kuwgi2PXuiSkHdNtmS8p1hAb21seijY5E/bigmaps/Assures/keys', (result) => {
      // https.get('https://api.ithacanet.tzkt.io/v1/contracts/'+contractKey+'/bigmaps/', (result) => {
        console.log('statusCode:', res.statusCode);
        
        let body = "";
        result.on("data", data => {
          body += data;
          
        });
    
        result.on("end", () => {
          body = JSON.parse(body);
  
          const colId = "valueType";
          const colData = body.map(obj => obj[colId]);
         
          res.json(colData);
        });
  
      }).on('error', (e) => {
        console.error(e);
      });
     
    });
    var path = require('path');
    app.get('/', function(request, response) {
  });
  






const port = process.env.port || 8081;

app.listen(port);

console.log('Smart Contract REST API server started on: ' + port);
module.exports.server = sls(app)
