const express = require('express')
const { InMemorySigner } = require('@taquito/signer');
const { TezBridgeSigner } = '@taquito/tezbridge-signer';
const {TezosToolkit, MichelCodecPacker } = require('@taquito/taquito');

const app = express()

const acc = require('../ithacanet.json')


const tezos = new TezosToolkit('https://ithacanet.smartpy.io');
const contractKey='KT1Kuwgi2PXuiSkHdNtmS8p1hAb21seijY5E';

tezos.setSignerProvider(InMemorySigner.fromFundraiser(acc.email, acc.password, acc.mnemonic.join(' ')))

  //*********************************Get Balance**************************************8 */

  app.get('/getBalance', (req,res) => {
    tezos.tz
    .getBalance(privateKey)
    .then((balance) => res.send(`Public key balance is: ${balance.toNumber() / 1000000} ꜩ`))
    .catch((error) => res.send(JSON.stringify(error)));

    
})



    //////////////////////////////////////////////////////////////////////////////////////////////////////
    ////                           ALL POST FUNCTIONS FOR THE SMART CONTRACT                          ////   
    //////////////////////////////////////////////////////////////////////////////////////////////////////




//*********************************Add Assurer***************************************/
app.post('addAssurer', (req,res) => {
  tezos.contract
    .at({contractKey})
    .then((contract) => {
      const email =req.body.email

      console.log(`Adding a assurer email: ${email}...`);
       contract.methods.addAssure(email).send();
    })
    .then((op) => {
      console.log(`Awaiting for ${op.hash} to be confirmed...`);
      return op.hash;
    })
  
.catch((error) => {
          // console.log(`Error: ${JSON.stringify(error, null, 2)}`))
          console.log(`Error: verify your infos`);
        
          })      
  
  })



//*********************************add subscription for an assurer**************************************8 */
app.post('/addSubscription', (req,res) => {
  tezos.contract
    .at(contractKey)
    .then((contract) => {
      const email = req.body.email
      const amount = req.body.amount
      const immatriculation = req.body.immatriculation
      const mode = req.body.mode
      const dateUpdate = req.body.dateUpdate
      const dateEmission = req.body.dateEmission
      const dateEcheance = req.body.dateEcheance
      const categorieDuvehicule = req.body.categorieDuvehicule
      const puissance = req.body.puissance
      const zone = req.body.zone
      const numeroAttestation = req.body.numeroAttestation
      const numeroCarteRose = req.body.numeroCarteRose
      const fc = req.body.fc
      const dta = req.body.dta
      const acc = req.body.acc
      const pna = req.body.pna
      const pttc = req.body.pttc
      const emailSouscripteur = req.body.emailSouscripteur
     
      // return contract.methods.addSouscription(email, amount, mode,dateUpdate,dateEmission, dateEcheance, categorieDuvehicule,puissance, zone, immatriculation, numeroAttestation,numeroCarteRose, fc, dta, acc, pna, pttc, emailSouscripteur).send();
      return contract.methods.addSouscription(acc,amount,categorieDuvehicule,dateEcheance,dateEmission, dateUpdate,dta, email.toString(), emailSouscripteur.toString(), fc,immatriculation, mode,numeroAttestation,numeroCarteRose, pna, pttc,  puissance, zone).send()

    })
      .then((op) => {
        return op.hash;
      })
    
  .catch((error) => {
            console.log(`Error: ${JSON.stringify(error, null, 2)}`)
            // console.log(`Error: verify your infos`);
    
    })
  })
  

