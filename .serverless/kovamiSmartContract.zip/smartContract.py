
import smartpy as sp
class KovamiSmartContract(sp.Contract):
    def __init__(self):
        self.init(Assures = sp.big_map())

    # Defines the addAssures entry point.
    @sp.entry_point
    def addAssure(self, params):
        # Verifies if mandatory fields have values. 
        sp.verify(params.email != "")
        # Declare the parameter types.
        sp.set_type(params.email, sp.TString)

        # Defines an assureur record, so we can add to a Map.
        Assure = sp.record(email=params.email, Souscription = sp.map())
        
        # Adds the new Assures record to a Map (that will reside in the contract's storage).
        self.data.Assures[params.email] = Assure   

    @sp.entry_point
    def getAssures(self):
        self.data.Assures

    @sp.entry_point
    def addSouscription(self, params):
        # Verifies if mandatory fields have values. 
        sp.verify(params.emailSouscripteur != "")
        sp.verify(params.email != "")        # Declare the parameter types.
        sp.set_type(params.emailSouscripteur, sp.TString)
        sp.set_type(params.email, sp.TString)
        sp.set_type(params.amount, sp.TInt)
        sp.set_type(params.dateEmission, sp.TString)
        sp.set_type(params.dateEcheance, sp.TString)
        sp.set_type(params.categorieDuvehicule, sp.TString)
        sp.set_type(params.puissance, sp.TInt)
        sp.set_type(params.zone, sp.TString)
        sp.set_type(params.immatriculation, sp.TString)
        sp.set_type(params.numeroAttestation, sp.TString)
        sp.set_type(params.numeroCarteRose, sp.TString)
        sp.set_type(params.fc, sp.TInt)
        sp.set_type(params.dta, sp.TInt)
        sp.set_type(params.acc, sp.TInt)
        sp.set_type(params.pna, sp.TInt)
        sp.set_type(params.pttc, sp.TInt)
        sp.set_type(params.mode, sp.TString)

        Souscripteur = sp.record(email= params.emailSouscripteur, amount = params.amount , mode=params.mode, dateUpdate=sp.timestamp_from_utc_now(),
        dateEmission=params.dateEmission, dateEcheance=params.dateEcheance, categorieDuvehicule=params.categorieDuvehicule,
        puissance=params.puissance, zone=params.zone, immatriculation=params.immatriculation, numeroAttestation=params.numeroAttestation,
        numeroCarteRose=params.numeroCarteRose, fc=params.fc, dta=params.dta, acc=params.acc, pna=params.pna, pttc=params.pttc
        )
        self.data.Assures[params.email].Souscription[params.emailSouscripteur]=Souscripteur
            


    @sp.add_test(name = "KovamiSmartContract")
    def test():
        # Instantiate a contract inherited from the Customer Class.
        myCustomersContract = KovamiSmartContract()
        
        # Defines a test scenario.
        scenario = sp.test_scenario()
        scenario.h2("Let's have a look at Kovami Smart contract Testing")


        # Adds the contract to the test scenario.
        scenario += myCustomersContract

        scenario.h2("Ajout Assure")
        
        #Add Assureur
        scenario += myCustomersContract.addAssure(email="jane@gmail.com")
        scenario += myCustomersContract.addAssure(email="kelly@gmail.com")

        
        #Create souscription
        scenario.h2("Let's Souscribe to an assurance")
        scenario += myCustomersContract.addSouscription(
        email= "jane@gmail.com", amount = 250000 , mode="Tez", dateUpdate=sp.timestamp_from_utc_now(),
        dateEmission="30/04/2022", dateEcheance="30/07/2022", categorieDuvehicule="Rav4",
        puissance=12, zone="Douala", immatriculation="HUTG7IB", numeroAttestation="NO246",
        numeroCarteRose="CR4356", fc=500, dta=45000, acc=1000, pna=150000, pttc=200000, emailSouscripteur="jane@gmail.com"
        )

        scenario += myCustomersContract.addSouscription(
        email= "jane@gmail.com", amount = 150000 , mode="Tez", dateUpdate=sp.timestamp_from_utc_now(),
        dateEmission="01/04/2022", dateEcheance="01/05/2022", categorieDuvehicule="BMW",
        puissance=60, zone="Yaounde", immatriculation="JI37F9", numeroAttestation="NO198",
        numeroCarteRose="CR4356", fc=1000, dta=35000, acc=1000, pna=80000, pttc=140000, emailSouscripteur="rakeal@gmail.com"
        )

        #List all assureur
        scenario.h2("List Assures")
        scenario += myCustomersContract.getAssures()
        

        


        
